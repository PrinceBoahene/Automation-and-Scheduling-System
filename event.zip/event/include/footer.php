
<script language="javascript" src="../plugins/jQuery/jquery.timers-1.0.0.js"></script>
<!-- <script language="javascript" src="./../plugins/jQuery/jquery.timers-1.0.0.js"></script> -->


<script>

  $(document).ready(function(){
   var j = jQuery.noConflict();
	j(document).ready(function()
	{
		j(".refresh").everyTime(1000,function(i){
			j.ajax({
			  url: "../views/timer2.php",
			  cache: false,
			  success: function(html){
				j(".refresh").html(html);
			  }
			})
		})
	});
   j('.refresh').css({color:"black"});
});

</script>
<p class="refresh"></p>
<div class=" pull-right hidden-xs"> <b> Version</b> 1.0.0 </div>

<!-- <div class="pull-right hidden-xs"> <b>Version</b> 2.3.0 </div> -->
<strong>Copyright &copy; <?php echo date("Y")-1 . " - ". date("Y"); ?> <a href="http://www.wedev.zyrosite.com" target="_blank">KsTU Automation and Scheduling System</a>.</strong> All rights reserved.


