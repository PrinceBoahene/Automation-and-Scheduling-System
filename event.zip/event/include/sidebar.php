<script language="javascript" src="../plugins/jQuery/jquery.timers-1.0.0.js"></script>
<!-- <script language="javascript" src="./../plugins/jQuery/jquery.timers-1.0.0.js"></script> -->


<script>

//   $(document).ready(function(){
//    var j = jQuery.noConflict();
// 	j(document).ready(function()
// 	{
// 		j(".refresh").everyTime(1000,function(i){
// 			j.ajax({
// 			  url: "../views/timer2.php",
// 			  cache: false,
// 			  success: function(html){
// 				j(".refresh").html(html);
// 			  }
// 			})
// 		})
// 	});
//    j('.refresh').css({color:"white"});
// });

</script>

<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
	<ul class="sidebar-menu">
		<li class="header">MAIN NAVIGATION</li>
		<li class="treeview">
			<a href="<?php echo WEB_ROOT; ?>views/?v=DB"><i class="fa fa-calendar"></i><span>Schedules Calendar</span></a>
		</li>
		<li class="treeview">
			<a href="<?php echo WEB_ROOT; ?>views/?v=LIST"><i class="fa fa-newspaper-o"></i><span>Schedule Lists</span></a>
		</li>
		<li class="treeview">
			<a href="<?php echo WEB_ROOT; ?>views/?v=Sub"><i class="fa fa-users"></i><span>Subscriptions</span></a>
		</li>
		
		<?php
		// $type2 = $_SESSION['calendar_fd_stu']['type'];
		$type = $_SESSION['calendar_fd_user']['type'];
		// $type2 = $_SESSION['calendar_fd_student']['type'];
	
// if(isset($_SESSION['calendar_fd_user'])){
// 	  $type = $_SESSION['calendar_fd_user']['type'];
// }

// if(isset($_SESSION['calendar_fd_stu'])){

// }else{
//   $type = $_SESSION['calendar_fd_user']['type'];

	
		if ($type == 'admin' || $type == 'teacher') {
		?>
		<li class="treeview">
			<a href="<?php echo WEB_ROOT; ?>views/?v=STUDENTS"><i class="fa fa-users"></i><span>Students</span></a>
		</li>
		<!--  -->
		<?php
		}
	// }
		// $type = $_SESSION['calendar_fd_user']['type'];
		// if(isset($_SESSION['calendar_fd_stu'])){

		// }else{
		//   $type = $_SESSION['calendar_fd_user']['type'];
	
	
		if ($type == 'admin' ) {
		?>
		<li class="treeview">
			<a href="<?php echo WEB_ROOT; ?>views/?v=USERS"><i class="fa fa-user"></i><span>Department </span></a>
		</li>
	
		<li class="treeview">
			<!-- <a href="<?php // echo WEB_ROOT; ?>views/?v=USERS"><i class="fa fa-user"></i><span>Institution</span></a> -->
		</li>
		<!-- <li class="treeview">
			<a href="<?php //echo WEB_ROOT; ?>views/?v=USERS"><i class="fa fa-users"></i><span>Institution Schedule Unit</span></a>
		</li> -->
		<!--  -->
		<li class="header">HOLIDAYS</li>
	
			<li class="treeview">
				<a href="<?php echo WEB_ROOT; ?>views/?v=HOLY"><i class="fa fa-plane"></i><span>National Holidays</span></a>
			</li>
			<li class="treeview">
				<!-- <a href="<?php // echo WEB_ROOT; ?>views/?v=HOLY"><i class="fa fa-plane"></i><span>Institutional Holidays</span></a> -->
			</li>

			<?php
		}
	// }
		?>

	
			<li class="treeview">
				
			</li>
			<li style="height: auto; width: auto; margin-top:10px; color: white; "> 
			
  <!-- <div class="refresh">

  </div> -->
  <!-- date -->
			</li>
	
	</ul>
	

		
	
</section>
<!-- /.sidebar -->





	