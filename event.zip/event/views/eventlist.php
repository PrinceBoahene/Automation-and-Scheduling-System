<?php 
$records = getBookingRecords();
$utype = '';
$type = $_SESSION['calendar_fd_user']['type'];
if($type == 'admin') {
	$utype = 'on';
}
?>

<div class="col-md-12">
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Schedule Details</h3>
      <a href="./print.php" class="btn btn-primary" target="_blank" title="Approved only" style="float: right;">Print List </a> <p style="float: right;"> | </p>
      <a href="" class="btn btn-success" target="" title="Subscribe" style="float: right;">SMS Alert </a> <p style="float: right;"> | </p>
      <a href="" class="btn btn-info" target="" style="float: right;">Add to Calendar </a>

    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <table class="table table-bordered">
        <tr>
          <th style="width: 10px">#</th>
          <th>Type</th>
          <th>Name</th>
          <th>Title</th>
          <th>Description</th>
          <th>Start Date</th>
          <th style="width: 140px">End Date</th>
          <th style="width: 100px">Status</th>
          <?php if($utype == 'on') { ?>
		  <th >Action</th>
		  <?php } ?>
        </tr>
        <?php
	  $idx = 1;
	  foreach($records as $rec) {
	  	extract($rec);
		$stat = '';
		if($status == "PENDING") {$stat = 'warning';}
		else if ($status == "APPROVED") {$stat = 'success';}
		else if($status == "DENIED") {$stat = 'danger';}
		?>
        <tr>
          <td><?php echo $idx++; ?></td>
          <td><?php echo $res_calenderTypeName; ?></td>
          <td><a href="<?php echo WEB_ROOT; ?>views/?v=USER&ID=<?php echo $user_id; ?>"><?php echo strtoupper($user_name); ?></a></td>
          <td><?php echo $res_title; ?></td>
          <td><?php echo $res_description; ?></td>
          <td><?php echo $res_date; ?></td>
          <td><?php echo $res_date2; ?></td>
          <td><span class="label label-<?php echo $stat; ?>"><?php echo $status; ?></span></td>
          <?php if($utype == 'on') { ?>
		  <td><?php if($status == "PENDING") {?>
            <a href="javascript:approve('<?php echo $res_id ?>');"> <span class='glyphicon glyphicon-ok'></span></a>&nbsp;|
			&nbsp;<a href="javascript:decline('<?php echo $res_id ?>');"> <span class='glyphicon glyphicon-remove'></span></a>&nbsp;|
			&nbsp;<a href="javascript:deleteUser('<?php echo $res_id ?>');"> <span class='glyphicon glyphicon-trash'></span></a>&nbsp;|
      &nbsp;<a href="javascript:EditUser('<?php echo $res_id ?>');"> <span class='glyphicon glyphicon-edit'></span></a>

            <?php } else { ?>
			<a href="javascript:deleteUser('<?php echo $res_id ?>');"> <span class='glyphicon glyphicon-trash'></span></a>
			<?php }//else ?>
          </td>
		  <?php } ?>
        </tr>
        <?php } ?>
      </table>
    </div>
    <!-- /.box-body -->
    <div class="box-footer clearfix">
      <!--
	<ul class="pagination pagination-sm no-margin pull-right">
      <li><a href="#">&laquo;</a></li>
      <li><a href="#">1</a></li>
      <li><a href="#">2</a></li>
      <li><a href="#">3</a></li>
      <li><a href="#">&raquo;</a></li>
    </ul>
	-->
      <?php echo generatePagination(); ?> </div>
  </div>
  <!-- /.box -->
</div>

<script language="javascript">
function approve(userId) {
	if(confirm('Are you sure you wants to Approve it ?')) {
		window.location.href = '<?php echo WEB_ROOT; ?>api/process.php?cmd=regConfirm&action=approve&userId='+userId;
	}
}
function decline(userId) {
	if(confirm('Are you sure you wants to Decline the Booking ?')) {
		window.location.href = '<?php echo WEB_ROOT; ?>api/process.php?cmd=regConfirm&action=denide&userId='+userId;
	}
}
function deleteUser(userId) {
	if(confirm('Deleting user will also delete it\'s booking from calendar.\n\nAre you sure you want to proceed ?')) {
		window.location.href = '<?php echo WEB_ROOT; ?>api/process.php?cmd=delete&userId='+userId;
	}
}
function EditUser(userId) {
	if(confirm('Are you sure you want to proceed editing? \n\n\nNot done yet')) {
		// window.location.href = '<?php //echo WEB_ROOT; ?>api/process.php?cmd=delete&userId='+userId;
	}
}


</script>
