<?php


require_once '../library/config.php';
require_once '../library/functions.php';

// $i = 0;
//  while($i < 10){
//      Echo $i++;
//  }
date_default_timezone_set('Africa/Accra');
//  echo date('h : m : s a');

// echo "<br>". date('d - M - Y');

$dateNow = date('Y-m-d h:m:s a');
echo $dateNow ."<br>";
// // $records = getBookingRecords();
$smsstatus="APPROVED";
$SMS = 1;
$sql 	= "SELECT * FROM tbl_reservations r  where Status ='$smsstatus' AND SMS !='$SMS'  ORDER BY r.id";
	//echo $sql;
	$result = dbQuery($sql);
	$records = array();

    while($hrow = dbFetchAssoc($result)) {	
		extract($hrow);
        
$startdate = new DateTime($rdate);
// $startdate = $rdate;
$enddate = $rdate2;
// echo "<br>"  .$startdate. "<br>";
$dateNow2 = new DateTime($dateNow);
$diff = $dateNow2 ->diff($startdate);//->format('%y yr, %m mths, %d days, %s secs');
// print_r($diff);
// echo $diff->format('%d days') ."<br>";
//get days 
$dayleft = $diff->format('%d days');
//get seconds left
$Secleft = $diff->format('%s sec');

// echo $dayleft . "  ". $Secleft."<br>";

if($dayleft == 0 && $Secleft == 0){

	// update event sms status
	$no = 1;
	$sqlup = "UPDATE tbl_reservations SET sms ='$no' ";
	$resultUp = dbQuery($sqlup);



}
echo $dayleft . "  ". $Secleft."<br>";

    }
// echo  "<br> Now = "  .$dateNow;

?>

