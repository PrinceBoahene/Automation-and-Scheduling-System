<link href="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.js" type="text/javascript"></script>

<script language="javascript" src="../plugins/jQuery/jquery.timers-1.0.0.js"></script>
<!-- <script language="javascript" src="../plugins/jQuery/timing.js"></script> -->


<!-- Horizontal Form -->
<div class="box box-info">
  <div class="box-header with-border">
    <h3 class="box-title">Student Subscriptions Form</h3>
  </div>
  <!-- /.box-header -->

  <div id="countd"></div>
  <!-- <div id="refresh"></div> -->

</div>
<!-- /.box -->

<script type="text/javascript">

const startingtime = 0.5;
let time = startingtime * 60;

const countdwn = document.getElementById('countd');

setInterval(updatetime, 1000);
function updatetime()
{
  const mins = Math.floor(time/60);
  let sec = time % 60;
  countdwn.innerHTML = `${mins}: ${sec}`;
 
if(sec > 0){
  time --;

}else{
  countdwn.innerHTML=`stop`;
// const startingtime = 0.1;

}
}
</script>

<?php 
// $records = getHolidayRecords();
?>
<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Subscriptions List</h3>
  </div>
  <!-- /.box-header -->
  <div class="box-body">

  
<?php   

$sql 	= "SELECT * FROM tbl_frontdesk_users";
$result = dbQuery($sql);
$records = array();


?>
    <table class="table table-bordered">
      <tr>
        <th style="width: 10px">#</th>
        <th>Name</th>
        <th>SMS alert</th>
        <th>Event Addons</th>
        
      </tr>
      <?php
	  $idx = 1;
	  while($hrow = dbFetchAssoc($result)) {	
      extract($hrow);
	  ?>
      <tr>
        <td><?php echo $idx++; ?></td>
        <td><?php echo $name; ?></a></td>

        <td><?php 
        if($SMSAlert == 1){ ?>
          <a href="javascript:SMSsubscribe('<?php echo $id ?>');"> <span class='glyphicon glyphicon-ok'></span></a>
       <?php  }else{ ?>
          <a href="javascript:SMSunsubscribe('<?php echo $id ?>');"> <span class='glyphicon glyphicon-remove'></span></a>
      <?php }
        ?></a></td>

        <td><?php 
        if($eventAddons == 1){ ?>
          <a href="javascript:subscribe('<?php echo $id ?>');"> <span class='glyphicon glyphicon-ok'></span></a>
       <?php  }else{ ?>
          <a href="javascript:subscribe('<?php echo $id ?>');"> <span class='glyphicon glyphicon-remove'></span></a>
      <?php }
        ?></a></td>

        
      </tr>
      <?php } ?>
    </table>
  </div>
  <!-- /.box-body -->
  <div class="box-footer clearfix">
    <?php echo generateHolidayPagination(); ?> </div>
</div>
<!-- /.box -->
<script language="javascript">
function SMSsubscribe(id) {
	if(confirm('Subscribing SMS alert you will receive notifications via SMS.\n\nAre you sure you want to proceed ?')) {
		// window.location.href = '<?php //echo WEB_ROOT; ?>api/process.php?cmd=hdelete&hId='+hid;
	}
}
function SMSUnsubscribe(id) {
	if(confirm('Unsubscribing SMS alert you will not receive any notification via SMS.\n\nAre you sure you want to proceed ?')) {

	}
}

</script>

