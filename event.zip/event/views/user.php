<?php
$userId = (isset($_GET['ID']) && $_GET['ID'] != '') ? $_GET['ID'] : 0;
$usql  = "SELECT * FROM tbl_users u WHERE u.id = $userId";
$res   = dbQuery($usql);
while ($row = dbFetchAssoc($res)) {
  extract($row);
  $stat = '';

  if ($status == "active") {
    $stat = 'success';
  } else if ($status == "lock") {
    $stat = 'warning';
  } else if ($status == "inactive") {
    $stat = 'warning';
  } else if ($status == "delete") {
    $stat = 'danger';
  }
?>
  <div class="col-md-6">
    <div class="box box-solid">
      <div class="box-header with-border"> <i class="fa fa-text-width"></i>
        <h3 class="box-title">Department Details</h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <dl class="dl-horizontal">
          <dt>Department Name</dt>
          <dd><?php echo $name; ?></dd>

          <dt>Department in Short</dt>
          <dd><?php echo $address; ?></dd>

          <dt>Email</dt>
          <dd><?php echo $email; ?></dd>

          <dt>Phone</dt>
          <dd><?php echo $phone; ?></dd>

          <dt>Booking Status</dt>
          <dd>
            <span class="label label-<?php echo $stat; ?>"><?php echo $status; ?></span>
          </dd>
        </dl>
        <dt>

        <dd>
          <a href="" class="btn btn-info">Edit</a> |
          <a href="" class="btn btn-info">Delete</a>
        </dd>
        <!-- <dd>
          <a href="" class="btn btn-info">Delete</a>
        </dd> -->
        </dt>


      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>

  <!-- schedules list  -->
  <?php 
$records = getBookingRecords();
$utype = '';
$type = $_SESSION['calendar_fd_user']['type'];
if($type == 'admin') {
	$utype = 'on';
}
?>
  <div class="col-md-6">
    <div class="box box-solid">
      <div class="box-header with-border"> <i class="fa fa-text-width"></i>
        <h3 class="box-title">Department Schedules</h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
      <table class="table table-bordered">
        <tr>
          <th style="width: 10px">#</th>
          <!-- <th>Type</th> -->
          <!-- <th>Name</th> -->
          <th>Title</th>
          <!-- <th>Description</th> -->
          <th>Start Date</th>
          <th style="width: 140px">End Date</th>
          <th style="width: 100px">Status</th>
         
        </tr>
        <?php
	  $idx = 1;
	  foreach($records as $rec) {
	  	extract($rec);
		$stat = '';
		if($status == "PENDING") {$stat = 'warning';}
		else if ($status == "APPROVED") {$stat = 'success';}
		else if($status == "DENIED") {$stat = 'danger';}
		?>
        <tr>
          <td><?php echo $idx++; ?></td>
          <!-- <td><?php // echo $res_calenderTypeName; ?></td> -->
          <!-- <td><a href="<?php //echo WEB_ROOT; ?>views/?v=USER&ID=<?php //echo $user_id; ?>"><?php //echo strtoupper($user_name); ?></a></td> -->
          <td><?php echo $res_title; ?></td>
          <!-- <td><?php echo $res_description; ?></td> -->
          <td><?php echo $res_date; ?></td>
          <td><?php echo $res_date2; ?></td>
          <td><span class="label label-<?php echo $stat; ?>"><?php echo $status; ?></span></td>
         
        </tr>
        <?php } ?>
      </table>


      </div>
    </div>
  </div>
    
    <?php
}
?>