
<div class="col-md-8">
  <?php include('calendar.php'); ?>
</div>
<!-- /.col -->
<div class="col-md-4">
<?php 

if(isset($_SESSION['calendar_fd_user'])){
		$type2 = $_SESSION['calendar_fd_user']['type'];
		include('eventform.php');
		}else{
			include('upcomingevent.php');
	
	}

// if(isset($_SESSION['calendar_fd_stu'])){
// 	$type2 = $_SESSION['calendar_fd_stu']['type'];
// 	include('upcomingevent.php');

// 	}else{
// 	  $type = $_SESSION['calendar_fd_user']['type'];
// 	include('eventform.php');

// }
?>	
</div>
<!-- /.col -->
