

<?php
require_once '../library/config.php';
require_once '../library/functions.php';

checkFDUser();

$view = (isset($_GET['v']) && $_GET['v'] != '') ? $_GET['v'] : '';

switch ($view) {
	case 'LIST':
		$content 	= 'eventlist.php';
		$pageTitle 	= 'View Event Details';
		break;

	case 'USERS':
		$content 	= 'userlist.php';
		$pageTitle 	= 'View User Details';
		break;

	case 'CREATE':
		$content 	= 'userform.php';
		$pageTitle 	= 'Create New User';
		break;

	case 'USER':
		$content 	= 'user.php';
		$pageTitle 	= 'View User Details';
		break;

	case 'STUDENTS':
		$content 	= 'studentlist.php';
		$pageTitle 	= 'View Students Details';
		break;

	case 'stuCREATE':
		$content 	= 'studentform.php';
		$pageTitle 	= 'Create New Student';
		break;
		
	case 'STUDENT':
		$content 	= 'student.php';
		$pageTitle 	= 'View Student Details';
		break;

	case 'Sub':
	$content 	= 'subscriptions.php';
	$pageTitle 	= 'Student Subscription';
	break;
	
	case 'HOLY':
		$content 	= 'holidays.php';
		$pageTitle 	= 'Holidays';
		break;
		// case 'CLOCK' :
		// 	$content 	= 'clock.php';		
		// 	$pageTitle 	= 'CLOCK';
		// 	break;	

	default:
		$content 	= 'dashboard.php';
		$pageTitle 	= 'Calendar Dashboard';
}

require_once '../include/template.php';
