<?php 

require_once '../library/config.php';
require_once '../library/functions.php';
require_once '../library/mail.php';

$cmd = isset($_GET['cmd']) ? $_GET['cmd'] : '';

switch($cmd) {
	
	case 'create':
		createUser();
	break;
	
	case 'change':
		changeStatus();
	break;
	
	case 'createStu':
		createStudent();
	break;
	case 'changeStu':
		changeStudentStatus();
	break;

	default :
	break;
}

function createUser() {
	$name 		= $_POST['name'];
	$address 	= $_POST['address'];
	$phone 		= $_POST['phone'];
	$email 		= $_POST['email'];
	$type		= $_POST['type'];
	// $department	=	$_POST['department'];
	
	//TODO first check if that date has a holiday
	$hsql	= "SELECT * FROM tbl_users WHERE name = '$name'";
	$hresult = dbQuery($hsql);
	if (dbNumRows($hresult) > 0) {
		$errorMessage = 'User with same name already exist. Please try another day.';
		header('Location: ../views/?v=CREATE&err=' . urlencode($errorMessage));
		exit();
	}
	$pwd = random_string();
	// $bkdate = Now();
	$sql = "INSERT INTO tbl_users (name, pwd, address, phone, email, type, status, bdate)
			VALUES ('$name', '$pwd', '$address', '$phone', '$email', '$type', 'active', NOW())";	
	dbQuery($sql);
	
	//send email on registration confirmation
	$bodymsg = "User $name booked the date slot on " & date("Y-M-d",) & ". Requesting you to please take further action on user booking.<br/>Mbr/>Tousif Khan";
	$data = array('to' => '$email', 'sub' => 'Booking on $rdate.', 'msg' => '$bodymsg');
	send_email($data);
	header('Location: ../views/?v=USERS&msg=' . urlencode('User successfully registered.'));
	exit();
}

//http://localhost/houda/views/process.php?cmd=change&action=inactive&userId=1
function changeStatus() {
	$action 	= $_GET['action'];
	$userId 	= (int)$_GET['userId'];
	
	
	$sql = "UPDATE tbl_users SET status = '$action' WHERE id = $userId";	
	dbQuery($sql);
	$name = "Prince";
	$bkdate = "2020-02-02";
	//send email on registration confirmation
	// $bodymsg = "User $name booked the date slot on $bkdate. Requesting you to please take further action on user booking.<br/>Mbr/>Tousif Khan";
	$bodymsg = "User $name booked the date slot on $bkdate. Requesting you to please take further action on user booking.<br/>Mbr/>Tousif Khan";
	$data = array('to' => '$email', 'sub' => 'Booking on $rdate.', 'msg' => $bodymsg);
	//send_email($data);
	header('Location: ../views/?v=USERS&msg=' . urlencode('User status successfully updated.'));
	exit();
}


function createStudent(){
	$name 		= $_POST['name'];
	$studentNo 	= $_POST['stuNo'];
	$phone 		= $_POST['phone'];
	$email 		= $_POST['email'];
	$depart		= $_POST['department'];
	// `name`, `contact`, `email`, `pwd`, `studentID`, `departID`, `eventAddons`,
	//  `SMSAlert`, `bdate`, `status`, `type` FROM `tbl_frontdesk_users

	//TODO first check if that student does not exist
	$hsql	= "SELECT * FROM tbl_frontdesk_users WHERE name = '$name' or studentID = '$studentNo' ";
	$hresult = dbQuery($hsql);
	if (dbNumRows($hresult) > 0) {
		$errorMessage = 'Student with same name or student Number already exist. Please try again.';
		header('Location: ../views/?v=stuCREATE&err=' . urlencode($errorMessage));
		exit();
	}
	$pwd = random_string();
	// $bkdate = Now();
	$sql = "INSERT INTO tbl_frontdesk_users (name, pwd, studentID, contact, email, departID, status, bdate,type)
			VALUES ('$name', '$pwd', '$studentNo', '$phone', '$email', '$depart', 'active', NOW(),'student')";	
	dbQuery($sql);
	
	//send email on registratioenn confirmation
	$bodymsg = "Dear $name, you have been added to KsTU automation and scheduling system. \r\nPassword = '$pwd'";
	$data = array('to' => $email, 'sub' => 'KsTU Scheduling System.', 'msg' => $bodymsg);
	send_email($data);
	header('Location: ../views/?v=STUDENTS&msg=' . urlencode('Student successfully registered.'));
	exit();
}

function changeStudentStatus() {
	$action 	= $_GET['action'];
	$userId 	= (int)$_GET['userId'];
	
	
	$sql = "UPDATE tbl_frontdesk_users SET status = '$action' WHERE id = $userId";	
	dbQuery($sql);
	$name = "Prince";
	$bkdate = "2020-02-02";
	$email ="nanakayprince19@gmail.com";
	//send email on registration confirmation
	// $bodymsg = "User $name booked the date slot on $bkdate. Requesting you to please take further action on user booking.<br/>Mbr/>Tousif Khan";
	$bodymsg = "User $name booked the date slot on $bkdate. Requesting you to please take further action on user booking.<br/>Mbr/>Tousif Khan";
	$data = array('to' => $email, 'sub' => 'Booking on $rdate.', 'msg' => $bodymsg);
	send_email($data);
	header('Location: ../views/?v=STUDENTS&msg=' . urlencode('Student status successfully updated.'));
	exit();
}

?>