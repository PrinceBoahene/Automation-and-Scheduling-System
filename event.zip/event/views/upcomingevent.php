<?php 
$records = getBookingRecords();
$utype = '';

if(isset($_SESSION['calendar_fd_stu'])){
$type2 = $_SESSION['calendar_fd_stu']['type'];
}else{
  $type = $_SESSION['calendar_fd_user']['type'];
$username  = $_SESSION['calendar_fd_user']['name'];

if($type == 'admin') {
	$utype = 'on';
}
}
?>
  



<link href="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textfieldvalidation/SpryValidationTextField.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/textareavalidation/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/textareavalidation/SpryValidationTextarea.js" type="text/javascript"></script>

<link href="<?php echo WEB_ROOT; ?>library/spry/selectvalidation/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<script src="<?php echo WEB_ROOT; ?>library/spry/selectvalidation/SpryValidationSelect.js" type="text/javascript"></script>

<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><b>Upcomimg Events</b></h3>
  </div>
  <!-- /.box-header -->
  <div class="box-body">
      <table class="table table-bordered">
        <tr>
          <th style="width: 10px">#</th>
          <th>Event Title</th>
          <th>Start Date</th>
          <th>End Date</th>
        </tr>
        <?php
	  $idx = 1;
	  foreach($records as $rec) {
	  	extract($rec);
		$stat = '';
		if($status == "PENDING") {$stat = 'warning';}
		else if ($status == "APPROVED") {$stat = 'success';}
		else if($status == "DENIED") {$stat = 'danger';}
		?>
        <tr>
          <td><?php echo $idx++; ?></td>
          <!-- <td><?php //echo $res_calenderTypeName; ?></td> -->
          <td><?php echo $res_title; ?></td>
          <!-- <td><?php // $res_description; ?></td> -->
          <td><?php echo $res_date; ?></td>
          <td><?php echo $res_date2; ?></td>
    
        <tr>

        </tr>

	 <?php } ?>
      </table>
    </div>
    <!-- /.box-body -->
    <div class="box-footer clearfix">


</div>
